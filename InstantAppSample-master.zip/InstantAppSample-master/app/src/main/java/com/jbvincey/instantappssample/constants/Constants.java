package com.jbvincey.instantappssample.constants;

/**
 * Created by jean-baptistevincey on 26/06/2017.
 */

public class Constants {

    public static final String BASE_URL = "https://instantapps.jbvincey.com";

}
